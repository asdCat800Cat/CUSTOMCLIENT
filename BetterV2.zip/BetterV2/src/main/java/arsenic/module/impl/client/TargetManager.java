package arsenic.module.impl.client;

import arsenic.main.Arsenic;
import arsenic.module.property.PropertyInfo;
import arsenic.utils.rotations.RotationUtils;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import arsenic.event.bus.Listener;
import arsenic.event.bus.annotations.EventLink;
import arsenic.event.impl.EventAttack;
import arsenic.module.Module;
import arsenic.module.ModuleCategory;
import arsenic.module.ModuleInfo;
import arsenic.module.property.impl.BooleanProperty;
import arsenic.module.property.impl.EnumProperty;
import arsenic.module.property.impl.doubleproperty.DoubleProperty;
import arsenic.module.property.impl.doubleproperty.DoubleValue;
import arsenic.utils.minecraft.PlayerUtils;
import java.util.Comparator;
import java.util.List;

@ModuleInfo(name = "Targets", category = ModuleCategory.SETTINGS)
public class TargetManager extends Module {
    public static EnumProperty<SortMode> sortMode = new EnumProperty<>("Sort Mode", SortMode.Distance);
    public static BooleanProperty teams = new BooleanProperty("Target Teammates", true),
            invis = new BooleanProperty("Target Invis", true),
            bots = new BooleanProperty("Target Bots", true),
            unArmoured = new BooleanProperty("Target UnArmoured", true),
            behindBlocks = new BooleanProperty("Behind Blocks", false);

    public static DoubleProperty fov = new DoubleProperty("General FOV", new DoubleValue(0, 360, 180, 1)),
            distance = new DoubleProperty("Distance", new DoubleValue(3, 10, 8, 1));

    private static EntityPlayer lockedTarget;
    private static long lockTimeOutStart = 0L;

    @Override
    protected void onEnable() {
        this.setEnabled(false);
    }

    private static double getFOV() {
        return fov.getValue().getInput();
    }

    @EventLink
    public Listener<EventAttack> eventAttackListener = e -> {
        // Al atacar a un jugador, se convierte en el objetivo bloqueado
        if (e.getTarget() instanceof EntityPlayer && e.getTarget() != mc.thePlayer) {
            lockedTarget = (EntityPlayer) e.getTarget();
            lockTimeOutStart = 0L;
        }
    };

    public static EntityPlayer getTarget() {
        // --- SISTEMA LOCKLIST ---
        if (lockedTarget != null) {
            // Si el objetivo muere o se desconecta/aleja demasiado (más de 50 bloques)
            if (!lockedTarget.isEntityAlive() || mc.thePlayer.getDistanceSqToEntity(lockedTarget) > 2500) {
                clearLock();
            } else if (isValidTarget(lockedTarget)) {
                // Cumple todas las condiciones: mantiene el bloqueo y reinicia el temporizador
                lockTimeOutStart = 0L;
                return lockedTarget;
            } else {
                // Dejó de cumplir condiciones (salió del FOV, rango o se cubrió con bloques)
                if (lockTimeOutStart == 0L) {
                    lockTimeOutStart = System.currentTimeMillis();
                }

                // Evaluación del tiempo de gracia de 2 segundos (2000 ms)
                if (System.currentTimeMillis() - lockTimeOutStart > 2000L) {
                    clearLock(); // Tiempo agotado: desbloquea
                } else {
                    // Sigue dentro de los 2 segundos de gracia:
                    // Retorna el objetivo bloqueado para mantener la prioridad absoluta y evitar cambiar a otro
                    return lockedTarget; 
                }
            }
        }

        // --- SELECCIÓN NORMAL ---
        List<EntityPlayer> en = PlayerUtils.getPlayersWithin(distance.getValue().getInput());
        en.removeIf(player -> !isValidTarget(player));
        return en.isEmpty() ? null : en.stream().min(Comparator.comparingDouble(target -> sortMode.getValue().sv.value(target))).get();
    }

    public static void clearLock() {
        lockedTarget = null;
        lockTimeOutStart = 0L;
    }

    private static boolean isValidTarget(EntityPlayer ep) {
        return (
                (ep != mc.thePlayer)
                        && (bots.getValue() || !AntiBot.isBot(ep))
                        && (teams.getValue() || !PlayerUtils.isEntityTeamSameAsPlayer(ep))
                        && (invis.getValue() || !ep.isInvisible())
                        && (unArmoured.getValue() || !PlayerUtils.isPlayerWearingArmour(ep))
                        && (behindBlocks.getValue() || mc.thePlayer.canEntityBeSeen(ep))
                        && PlayerUtils.withinFov(ep, (float) getFOV())
                        && (mc.thePlayer.getDistanceToEntity(ep) <= distance.getValue().getInput())
        );
    }

    public enum SortMode {
        Distance(player -> mc.thePlayer.getDistanceToEntity(player)),
        HurtSwitch(player -> (float) player.hurtTime),
        Fov(player -> (float) Math.abs(RotationUtils.fovFromEntity(player))),
        Health(EntityLivingBase::getHealth);

        private final SortValue sv;
        SortMode(SortValue sv) {
            this.sv = sv;
        }
    }

    @FunctionalInterface
    private interface SortValue {
        Float value(EntityPlayer player);
    }
}