package arsenic.module.impl.ghost;

import arsenic.asm.RequiresPlayer;
import arsenic.event.bus.Listener;
import arsenic.event.bus.annotations.EventLink;
import arsenic.event.impl.EventSilentRotation;
import arsenic.module.Module;
import arsenic.module.ModuleCategory;
import arsenic.module.ModuleInfo;
import arsenic.module.impl.client.TargetManager;
import arsenic.module.property.PropertyInfo;
import arsenic.module.property.impl.BooleanProperty;
import arsenic.module.property.impl.EnumProperty;
import arsenic.module.property.impl.rangeproperty.RangeProperty;
import arsenic.module.property.impl.rangeproperty.RangeValue;
import arsenic.utils.rotations.RotationUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemSword;
import net.minecraft.util.MovingObjectPosition;

@ModuleInfo(name = "SmoothAim", category = ModuleCategory.GHOST)
public class SmoothAim extends Module {

    public final EnumProperty<aaMode> mode = new EnumProperty<>("Mode: ", aaMode.Assist);

    @PropertyInfo(reliesOn = "Mode: ", value = "Silent")
    public final BooleanProperty movementFix = new BooleanProperty("MovementFix", true);

    public final BooleanProperty clickOnly = new BooleanProperty("ClickOnly", true);
    public final BooleanProperty weaponOnly = new BooleanProperty("Weapon Only", false);
    public final BooleanProperty fovBased = new BooleanProperty("FovBased", true);
    public final BooleanProperty pitchAssist = new BooleanProperty("PitchAssist", true);
    public final BooleanProperty breakBlocks = new BooleanProperty("Break Blocks", false);

    public final RangeProperty speed = new RangeProperty("Speed", new RangeValue(1, 100, 45, 80, 1));
    public final RangeProperty compliment = new RangeProperty("Compliment", new RangeValue(2, 97, 15, 30, 1));

    @Override
    protected void onDisable() {
        TargetManager.clearLock(); // Limpia el bloqueo al desactivar el módulo
    }

    @RequiresPlayer
    @EventLink
    public Listener<EventSilentRotation> eventSilentRotationListener = event -> {
        if (mc.currentScreen != null) return;
        if (clickOnly.getValue() && !mc.gameSettings.keyBindAttack.isKeyDown()) return;
        if (breakBlocks.getValue() && mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) return;

        if (weaponOnly.getValue()) {
            if (mc.thePlayer.getCurrentEquippedItem() == null) return;
            boolean isWeapon = mc.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemSword
                            || mc.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemAxe;
            if (!isWeapon) return;
        }

        EntityAndRots target = getTargetAndRotations();
        if (target == null) return;

        double fov = RotationUtils.fovFromEntity(target.entity);
        double rotSpeed = speed.getValue().getRandomInRange() * (fovBased.getValue() ? (Math.abs(fov) * 2 / 180) : 1);

        if (mode.getValue() == aaMode.Silent) {
            event.setDoMovementFix(movementFix.getValue());
            event.setJumpFix(movementFix.getValue());
            event.setSpeed((float) rotSpeed);
            event.setYaw(target.yaw);
            event.setPitch(target.pitch);
        } else if (mode.getValue() == aaMode.Normal) {
            float[] rots = RotationUtils.getPatchedAndCappedRots(
                    new float[]{mc.thePlayer.prevRotationYaw, mc.thePlayer.prevRotationPitch},
                    new float[]{target.yaw, target.pitch},
                    (float) rotSpeed
            );
            mc.thePlayer.rotationYaw = rots[0];
            mc.thePlayer.rotationPitch = rots[1];
        } else if (mode.getValue() == aaMode.Assist) {
            if (Math.abs(fov) > 1.0D) {
                double compVal = compliment.getValue().getRandomInRange();
                double spdVal = speed.getValue().getRandomInRange();

                double complimentSpeed = fov * (compVal / 100.0D);
                float val = (float) (-(complimentSpeed + fov / (101.0D - spdVal)));

                mc.thePlayer.rotationYaw += val;

                if (pitchAssist.getValue()) {
                    float[] rots = RotationUtils.getPatchedAndCappedRots(
                            new float[]{mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch},
                            new float[]{mc.thePlayer.rotationYaw, target.pitch},
                            (float) rotSpeed
                    );
                    mc.thePlayer.rotationPitch = rots[1];
                }
            }
        }
    };

    private EntityAndRots getTargetAndRotations() {
        EntityAndRots target = new EntityAndRots();
        target.entity = TargetManager.getTarget();
        if (target.entity == null) return null;
        float[] rotationsToTarget = RotationUtils.getRotationsToEntity((EntityLivingBase) target.entity);
        target.yaw = rotationsToTarget[0];
        target.pitch = (float) ((pitchAssist.getValue() ? rotationsToTarget[1] : mc.thePlayer.rotationPitch) + Math.random() - Math.random());
        return target;
    }

    private static class EntityAndRots {
        public Entity entity;
        public float yaw, pitch;
    }

    public enum aaMode {
        Silent,
        Normal,
        Assist
    }
}