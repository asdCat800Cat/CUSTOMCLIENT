package arsenic.module.impl.ghost;

import arsenic.module.Module;
import arsenic.module.ModuleCategory;
import arsenic.module.ModuleInfo;
import arsenic.module.property.impl.BooleanProperty;
import arsenic.module.property.impl.EnumProperty;
import arsenic.module.property.impl.doubleproperty.DoubleProperty;
import arsenic.module.property.impl.doubleproperty.DoubleValue;
import arsenic.event.bus.annotations.EventLink;
import arsenic.event.bus.Listener;
import arsenic.event.impl.EventUpdate;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemSword;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Mouse;
import java.util.concurrent.ThreadLocalRandom;

@ModuleInfo(name = "SmoothAim", category = ModuleCategory.GHOST)
public class SmoothAim extends Module {

    // Aim Settings
    public final EnumProperty<AimMode> mode = new EnumProperty<>("Mode", AimMode.REGULAR);
    public final DoubleProperty horizontalSpeed1 = new DoubleProperty("Horizontal Speed 1", new DoubleValue(45.0, 5.0, 100.0, 1.0));
    public final DoubleProperty horizontalSpeed2 = new DoubleProperty("Horizontal Speed 2", new DoubleValue(15.0, 2.0, 97.0, 1.0));
    public final DoubleProperty verticalSpeed1 = new DoubleProperty("Vertical Speed 1", new DoubleValue(45.0, 5.0, 100.0, 1.0));
    public final DoubleProperty verticalSpeed2 = new DoubleProperty("Vertical Speed 2", new DoubleValue(15.0, 2.0, 97.0, 1.0));
    public final DoubleProperty multiPoint = new DoubleProperty("Multi-point", new DoubleValue(50.0, 0.0, 100.0, 1.0));
    public final DoubleProperty randomization = new DoubleProperty("Randomization", new DoubleValue(50.0, 0.0, 100.0, 1.0));

    // Target Settings
    public final EnumProperty<TargetMode> targetMode = new EnumProperty<>("Mode", TargetMode.SINGLE);
    public final DoubleProperty range = new DoubleProperty("Range", new DoubleValue(4.5, 1.0, 10.0, 0.1));
    public final DoubleProperty fov = new DoubleProperty("FOV", new DoubleValue(90.0, 15.0, 360.0, 1.0));

    // Conditionals Settings
    public final BooleanProperty sprinting = new BooleanProperty("Sprinting", false);
    public final BooleanProperty mousePressed = new BooleanProperty("Mouse pressed", true);
    public final BooleanProperty disableWhileBreakingBlocks = new BooleanProperty("Disable while breaking blocks", true);
    public final BooleanProperty holdingWeapon = new BooleanProperty("Holding weapon", true);
    public final BooleanProperty ignoreInvisibles = new BooleanProperty("Ignore invisibles", true);
    public final BooleanProperty notBehindBlocks = new BooleanProperty("Not behind blocks", true);

    public enum AimMode { REGULAR }
    public enum TargetMode { SINGLE }

    @EventLink
    public final Listener<EventUpdate> onUpdate = event -> {
        if (mc.theWorld == null || mc.thePlayer == null) return;

        if (disableWhileBreakingBlocks.getValue() && mc.objectMouseOver != null) {
            BlockPos p = mc.objectMouseOver.getBlockPos();
            if (p != null) {
                Block bl = mc.theWorld.getBlockState(p).getBlock();
                if (!(bl instanceof BlockAir) && !(bl instanceof BlockLiquid)) {
                    return;
                }
            }
        }

        if (sprinting.getValue() && !mc.thePlayer.isSprinting()) return;
        if (holdingWeapon.getValue() && !isHoldingWeapon()) return;
        if (mousePressed.getValue() && !Mouse.isButtonDown(0)) return;

        EntityPlayer target = getEnemy();
        if (target != null) {
            double[] diffs = getRotations(target);
            double fovDiffYaw = diffs[0];
            double fovDiffPitch = diffs[1];

            // Randomization Logic
            double randAmount = randomization.getValue().getInput() / 100.0;
            double randYawOffset = (ThreadLocalRandom.current().nextDouble() - 0.5) * randAmount * 2.0;
            double randPitchOffset = (ThreadLocalRandom.current().nextDouble() - 0.5) * randAmount * 2.0;

            // Horizontal Aiming
            if (Math.abs(fovDiffYaw) > 1.0D) {
                double speed2 = horizontalSpeed2.getValue().getInput();
                double speed1 = horizontalSpeed1.getValue().getInput();
                
                double complimentSpeed = fovDiffYaw * (ThreadLocalRandom.current().nextDouble(speed2 - 1.47328, speed2 + 2.48293) / 100.0);
                float valYaw = (float) (-(complimentSpeed + fovDiffYaw / (101.0D - (float) ThreadLocalRandom.current().nextDouble(speed1 - 4.723847, speed1))));
                
                mc.thePlayer.rotationYaw += valYaw + randYawOffset;
            }

            // Vertical Aiming
            if (Math.abs(fovDiffPitch) > 1.0D) {
                double vSpeed2 = verticalSpeed2.getValue().getInput();
                double vSpeed1 = verticalSpeed1.getValue().getInput();

                double vComplimentSpeed = fovDiffPitch * (ThreadLocalRandom.current().nextDouble(vSpeed2 - 1.47328, vSpeed2 + 2.48293) / 100.0);
                float valPitch = (float) (-(vComplimentSpeed + fovDiffPitch / (101.0D - (float) ThreadLocalRandom.current().nextDouble(vSpeed1 - 4.723847, vSpeed1))));
                
                float newPitch = mc.thePlayer.rotationPitch + valPitch + (float)randPitchOffset;
                // Clamp pitch to prevent screen flipping (breaking neck)
                mc.thePlayer.rotationPitch = MathHelper.clamp_float(newPitch, -90.0F, 90.0F);
            }
        }
    };

    private EntityPlayer getEnemy() {
        EntityPlayer bestTarget = null;
        double bestFov = fov.getValue().getInput();
        
        for (Entity entity : mc.theWorld.playerEntities) {
            if (entity instanceof EntityPlayer) {
                EntityPlayer en = (EntityPlayer) entity;
                if (en == mc.thePlayer || en.isDead || en.deathTime != 0) continue;
                if (ignoreInvisibles.getValue() && en.isInvisible()) continue;
                if (mc.thePlayer.getDistanceToEntity(en) > range.getValue().getInput()) continue;
                if (notBehindBlocks.getValue() && !mc.thePlayer.canEntityBeSeen(en)) continue;

                double currentFov = Math.abs(getFovDifference(en));
                if (currentFov < bestFov) {
                    bestFov = currentFov;
                    bestTarget = en;
                }
            }
        }
        return bestTarget;
    }

    private boolean isHoldingWeapon() {
        return mc.thePlayer.getHeldItem() != null && 
               (mc.thePlayer.getHeldItem().getItem() instanceof ItemSword || 
                mc.thePlayer.getHeldItem().getItem() instanceof ItemAxe);
    }

    private double getFovDifference(Entity entity) {
        double diffX = entity.posX - mc.thePlayer.posX;
        double diffZ = entity.posZ - mc.thePlayer.posZ;
        double yaw = Math.atan2(diffZ, diffX) * 180.0D / Math.PI - 90.0D;
        return MathHelper.wrapAngleTo180_float((float) (yaw - mc.thePlayer.rotationYaw));
    }
    
    private double[] getRotations(Entity entity) {
        double diffX = entity.posX - mc.thePlayer.posX;
        double diffZ = entity.posZ - mc.thePlayer.posZ;

        // Multi-point calculation
        // multiPoint slider (0-100): 0 = feet, 50 = center/chest, 100 = head
        double yPercent = multiPoint.getValue().getInput() / 100.0;
        double targetY = entity.getEntityBoundingBox().minY + (entity.getEntityBoundingBox().maxY - entity.getEntityBoundingBox().minY) * yPercent;
        
        // Calculate difference taking into account the player's eye height
        double diffY = targetY - (mc.thePlayer.posY + (double) mc.thePlayer.getEyeHeight());

        double dist = (double) MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        double yaw = Math.atan2(diffZ, diffX) * 180.0D / Math.PI - 90.0D;
        double pitch = -(Math.atan2(diffY, dist) * 180.0D / Math.PI);

        double yawDiff = MathHelper.wrapAngleTo180_float((float) (yaw - mc.thePlayer.rotationYaw));
        double pitchDiff = MathHelper.wrapAngleTo180_float((float) (pitch - mc.thePlayer.rotationPitch));

        return new double[]{yawDiff, pitchDiff};
    }
}
